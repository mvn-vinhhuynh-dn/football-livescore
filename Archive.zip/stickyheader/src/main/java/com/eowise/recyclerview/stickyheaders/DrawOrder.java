package com.eowise.recyclerview.stickyheaders;

/**
 * Created by aurel on 10/11/14.
 */
public enum DrawOrder {
    OverItems,
    UnderItems
}
